window.OMUTA_SHARED_CONFIG={url:'',publishableKey:''};
