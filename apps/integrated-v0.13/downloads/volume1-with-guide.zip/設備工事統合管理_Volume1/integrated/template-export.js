/* Fill the supplied city workbook, preserving its cell styles and print geometry. */
(()=>{'use strict';
const NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main',RNS='http://schemas.openxmlformats.org/officeDocument/2006/relationships',PKG='http://schemas.openxmlformats.org/package/2006/relationships';
const decoder=new TextDecoder(),encoder=new TextEncoder(),xml=new XMLSerializer();
const parse=b=>{const d=new DOMParser().parseFromString(decoder.decode(b),'application/xml');if(d.querySelector('parsererror'))throw Error('基準書式のXMLを読み取れません。');return d;};
const elements=(d,tag)=>[...d.getElementsByTagNameNS(NS,tag)];
function restoreCompatibilityNamespaces(doc){
 const compatibility='http://schemas.openxmlformats.org/markup-compatibility/2006',xmlns='http://www.w3.org/2000/xmlns/';
 const known={x14ac:'http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac',x16r2:'http://schemas.microsoft.com/office/spreadsheetml/2015/02/main',xr:'http://schemas.microsoft.com/office/spreadsheetml/2014/revision',xr2:'http://schemas.microsoft.com/office/spreadsheetml/2015/revision2',xr3:'http://schemas.microsoft.com/office/spreadsheetml/2016/revision3'};
 for(const element of [...doc.getElementsByTagName('*')]){const value=element.getAttributeNS(compatibility,'Ignorable');if(!value)continue;for(const prefix of value.trim().split(/\s+/)){if(element.lookupNamespaceURI(prefix))continue;if(!known[prefix])throw Error('Excel拡張機能の名前空間を確認できません：'+prefix);doc.documentElement.setAttributeNS(xmlns,'xmlns:'+prefix,known[prefix]);}}
}
function removeUnusedExternalNames(workbook,sheets){
 const names=elements(workbook,'definedName'),external=names.filter(e=>/\[\d+\]/.test(e.textContent||''));
 const expressions=sheets.flatMap(doc=>['f','formula','formula1','formula2'].flatMap(tag=>elements(doc,tag).map(e=>e.textContent||''))).concat(names.filter(e=>!external.includes(e)).map(e=>e.textContent||''));
 const text=expressions.map(value=>value.replace(/"(?:[^"]|"")*"/g,'')).join('\n');
 for(const entry of external){const name=entry.getAttribute('name'),escaped=[...name].map(c=>'\\^$.*+?()[]{}|'.includes(c)?'\\'+c:c).join(''),pattern=new RegExp('(^|[^A-Za-z0-9_.$\\u0080-\\uFFFF])'+escaped+'(?![A-Za-z0-9_.$!\\u0080-\\uFFFF])','i');if(pattern.test(text))throw Error('外部参照名が計算に使用されています。出力前に確認してください：'+name);}
 external.forEach(entry=>entry.remove());return external.length;
}
function colNumber(ref){let n=0;for(const c of ref.match(/^[A-Z]+/)[0])n=n*26+c.charCodeAt(0)-64;return n;}
function column(n){let s='';while(n){n--;s=String.fromCharCode(65+n%26)+s;n=Math.floor(n/26);}return s;}
function cell(d,ref){let c=elements(d,'c').find(c=>c.getAttribute('r')===ref);if(c)return c;
 const num=Number(ref.match(/\d+$/)[0]),data=elements(d,'sheetData')[0];let row=elements(data,'row').find(r=>Number(r.getAttribute('r'))===num);
 if(!row){row=d.createElementNS(NS,'row');row.setAttribute('r',num);row.setAttribute('ht','22.5');row.setAttribute('customHeight','1');const next=elements(data,'row').find(r=>Number(r.getAttribute('r'))>num);data.insertBefore(row,next||null);}
 c=d.createElementNS(NS,'c');c.setAttribute('r',ref);const next=[...row.children].find(x=>x.localName==='c'&&colNumber(x.getAttribute('r'))>colNumber(ref));row.insertBefore(c,next||null);return c;
}
function put(d,ref,value,formula=null){const c=cell(d,ref);c.replaceChildren();c.removeAttribute('t');
 if(value===null||value===undefined||value===''){if(!formula)return;}
 if(formula!==null){const f=d.createElementNS(NS,'f');f.textContent=formula;c.append(f);}
 if(typeof value==='number'){if(!Number.isFinite(value))throw Error('出力値が不正です：'+ref);const v=d.createElementNS(NS,'v');v.textContent=String(value);c.append(v);}
 else if(value!==null&&value!==undefined&&value!==''){if(formula!==null){c.setAttribute('t','str');const v=d.createElementNS(NS,'v');v.textContent=String(value);c.append(v);}else{c.setAttribute('t','inlineStr');const is=d.createElementNS(NS,'is'),t=d.createElementNS(NS,'t');t.setAttributeNS('http://www.w3.org/XML/1998/namespace','xml:space','preserve');t.textContent=String(value);is.append(t);c.append(is);}}
}
function clearRows(d,start,end,cols=100){elements(d,'c').filter(c=>{const ref=c.getAttribute('r'),r=Number(ref.match(/\d+$/)[0]);return r>=start&&r<=end&&colNumber(ref)<=cols;}).forEach(c=>{c.replaceChildren();c.removeAttribute('t');});}
function freeze(d){elements(d,'c').forEach(c=>{const f=elements(c,'f')[0];if(!f)return;f.remove();if(c.getAttribute('t')==='e'){c.replaceChildren();c.removeAttribute('t');}});}
function cloneRow(d,template,num){const copy=template.cloneNode(true);copy.setAttribute('r',num);for(const c of elements(copy,'c')){c.setAttribute('r',c.getAttribute('r').replace(/\d+$/,String(num)));c.replaceChildren();c.removeAttribute('t');}const old=elements(d,'row').find(r=>Number(r.getAttribute('r'))===num);if(old)old.replaceWith(copy);else elements(d,'sheetData')[0].append(copy);return copy;}
function sortRows(d){const data=elements(d,'sheetData')[0];[...data.children].sort((a,b)=>Number(a.getAttribute('r'))-Number(b.getAttribute('r'))).forEach(r=>data.append(r));}
function printSetup(d,lastCol,lastRow,wide=false){elements(d,'dimension')[0]?.setAttribute('ref','A1:'+lastCol+lastRow);let pr=elements(d,'sheetPr')[0];if(!pr){pr=d.createElementNS(NS,'sheetPr');d.documentElement.prepend(pr);}let fit=elements(pr,'pageSetUpPr')[0];if(!fit){fit=d.createElementNS(NS,'pageSetUpPr');pr.append(fit);}fit.setAttribute('fitToPage','1');
 let setup=elements(d,'pageSetup')[0];if(!setup){setup=d.createElementNS(NS,'pageSetup');const after=elements(d,'headerFooter')[0];d.documentElement.insertBefore(setup,after||null);}setup.setAttribute('paperSize',wide?'8':'9');setup.setAttribute('orientation',wide?'landscape':'portrait');setup.setAttribute('fitToWidth','1');setup.setAttribute('fitToHeight','0');
 const view=elements(d,'sheetView')[0];if(view){view.setAttribute('view','pageBreakPreview');view.removeAttribute('tabSelected');const pane=elements(view,'pane')[0];if(pane){const frozenColumns=Number(pane.getAttribute('xSplit')||0),frozenRows=wide?4:1;pane.setAttribute('state','frozen');pane.setAttribute('topLeftCell',column(frozenColumns+1)+(frozenRows+1));pane.setAttribute('ySplit',String(frozenRows));pane.setAttribute('activePane',frozenColumns?'bottomRight':'bottomLeft');}}
}
const textWidth=s=>[...String(s)].reduce((n,c)=>n+(c.charCodeAt(0)>255?2:1),0);
function simpleSheet(rows,wrapStyle){const d=new DOMParser().parseFromString('<worksheet xmlns="'+NS+'"><dimension ref="A1:A1"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="2" topLeftCell="A3" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="26"/><cols/><sheetData/><pageMargins left="0.3" right="0.3" top="0.5" bottom="0.5" header="0.2" footer="0.2"/></worksheet>','application/xml');
 rows.forEach((row,r)=>{let lines=1;row.forEach((v,c)=>{put(d,column(c+1)+(r+1),v);cell(d,column(c+1)+(r+1)).setAttribute('s',wrapStyle);const width=c===0?24:c<=4?22:36;lines=Math.max(lines,String(v??'').split('\n').reduce((n,l)=>n+Math.max(1,Math.ceil(textWidth(l)/(width-2))),0));});const out=elements(d,'row').find(x=>x.getAttribute('r')===String(r+1));out.setAttribute('ht',Math.max(26,lines*15+4));});const width=elements(d,'cols')[0];for(let c=1;c<=Math.max(...rows.map(r=>r.length));c++){const e=d.createElementNS(NS,'col');e.setAttribute('min',c);e.setAttribute('max',c);e.setAttribute('width',c===1?'24':c<=5?'22':'36');e.setAttribute('customWidth','1');width.append(e);}printSetup(d,column(Math.max(...rows.map(r=>r.length))),rows.length,true);return d;
}
async function exportTemplate(){
 const p=WB.project(),items=WB.adopted(p),s=p.settings,t=WB.totals(p),budget=s.purpose==='予算用',label=WB.ready()?'確認済み':'途中確認';
 if(!items.length)throw Error('先に項目を採用してください。');if(t.formulaError)throw Error(t.formulaError);
 const files=await unzipSimple(Uint8Array.from(atob(WB_EXPORT_TEMPLATES[budget?'budget':'design']),c=>c.charCodeAt(0)));
 const wb=parse(files['xl/workbook.xml']),rels=parse(files['xl/_rels/workbook.xml.rels']),ct=parse(files['[Content_Types].xml']);
 const names=elements(wb,'sheet').map(e=>e.getAttribute('name')),docs=names.map((_,k)=>parse(files['xl/worksheets/sheet'+(k+1)+'.xml']));
 const commonIndex=budget?2:1,detailIndex=budget?3:2,priceIndex=budget?5:3,common=docs[commonIndex],detail=docs[detailIndex],price=docs[priceIndex];
 // Read rounding and labor formulas from the supplied workbook before clearing rows.
 const sourceUnitFormulas=Object.fromEntries(['L','M','N','O','P','Q','R','S'].map(col=>{
  const formula=elements(cell(price,col+'6'),'f')[0]?.textContent;
  if(!formula)throw Error('基準書式の単価計算式がありません：'+col+'6');
  return [col,formula];
 }));
 function unitFormula(col,ur,pr,sharedElectric,sharedOrdinary){
  return sourceUnitFormulas[col].replace(/(\$?[A-Z]{1,3})(\$?)(\d+)/g,(ref,c,fixed,row)=>{
   if(ref==='J$1'&&!sharedElectric)return 'U'+ur;
   if(ref==='J$2'&&!sharedOrdinary)return 'V'+ur;
   if(fixed)return ref;
   return c+(Number(row)===5?ur:Number(row)===6?pr:row);
  });
 }
 const commonName=names[commonIndex],priceName=names[priceIndex],year=String(s.year).match(/令和\s*(\d+)/)?.[1]||'',title=p.title.replace(/^大牟田市\s*/,'').replace(/工事$/,'');
 const periodText=WB.contractPeriod(s),periodMatch=periodText.match(/^(.*?)([0-9０-９]+(?:[.．][0-9０-９]+)?)\s*日間\s*$/);
 const periodPrefix=periodMatch?periodMatch[1].trim():periodText,periodDays=periodMatch?Number(periodMatch[2].normalize('NFKC')):null;
 // Preserve source auxiliary formulas and names. They are reference material, not adopted calculations.
 elements(wb,'sheet').forEach((sh,k)=>{if(![0,...(budget?[1]:[]),commonIndex,detailIndex,priceIndex].includes(k))sh.setAttribute('state','hidden');});
 function write(d,rows){rows.forEach(([r,v,f])=>put(d,r,v,f===undefined?null:f));}
 if(budget){for(const k of [0,1]){const d=docs[k];write(d,[['C15',year?Number(year):null],['D19',title],['D22',s.location||''],['G22',null],['U22',WB.contractPeriod(s)],['AC22',null],['F24',null],['D24',null],['G24',null],['E26',s.overview||''],['J26',''],['D30',label],['Y38',t.direct,"'内訳書'!G4"],['Y39',t.common,"'内訳書'!G6"],['Y40',t.management,"'内訳書'!G8"],['Y41',t.general,"'内訳書'!G10"],['Y42',null],['Y43',t.price,"'内訳書'!G12"],['Y47',t.tax,"'内訳書'!G14"],['AC47','消費税'+s.tax+'%'],['Y49',t.total,'SUM(Y43,Y47)'],['Y51',t.budget,'ROUNDUP(Y49,-4)']]);}}
 else {const d=docs[0];write(d,[['C16',year?Number(year):null],['D20',title],['U20',s.person||''],['M22',s.location||''],['U23',periodPrefix],['AD23',periodDays],['AF23',periodDays===null?'':'　日間'],['E25',s.overview||''],['J25',''],['X18',null],['X17',null],['Z17',null],['AB17',null],['E10',null]]);
  for(const [n,previous] of [[48,16],[80,48],[112,80]])put(d,'C'+n,year?Number(year):null,`IF(ISBLANK(C${previous}),"",C${previous})`);
  for(const [row,prev] of [[52,20],[84,52],[116,84]])put(d,'D'+row,title,`IF(ISBLANK(D${prev}),"",D${prev})`);
  for(const [loc,period,overview] of [[54,55,57],[86,87,89],[118,119,121]]){write(d,[['M'+loc,s.location||'','M22'],['U'+period,periodPrefix,'U23'],['AD'+period,periodDays,periodDays===null?undefined:'AD23'],['AF'+period,periodDays===null?'':'　日間'],['E'+overview,s.overview||'','E25'],['J'+overview,'']]);}
 }
 const start=budget?78:39,minSum=budget?134:72,sumRow=Math.max(minSum,start+items.length),lastDetail=start+items.length-1,finalSum=budget?sumRow+1:sumRow;
 const oldRow=elements(detail,'row').find(r=>Number(r.getAttribute('r'))===start).cloneNode(true),sumTemplate=elements(detail,'row').find(r=>Number(r.getAttribute('r'))===minSum).cloneNode(true);
 const styles=parse(files['xl/styles.xml']),xfs=elements(styles,'cellXfs')[0],baseStyle=Number(cell(detail,'C'+start).getAttribute('s')||0),wrap=xfs.children[baseStyle].cloneNode(true),wrapStyle=String(xfs.children.length);
 let align=elements(wrap,'alignment')[0];if(!align){align=styles.createElementNS(NS,'alignment');wrap.append(align);}align.setAttribute('wrapText','1');align.setAttribute('vertical','top');wrap.setAttribute('applyAlignment','1');xfs.append(wrap);xfs.setAttribute('count',String(xfs.children.length));files['xl/styles.xml']=encoder.encode(xml.serializeToString(styles));
 clearRows(detail,start,Math.max(204,finalSum+3));if(budget)clearRows(detail,50,51);put(detail,'A2',p.title);
 const upper=elements(price,'row').find(r=>r.getAttribute('r')==='5').cloneNode(true),lower=elements(price,'row').find(r=>r.getAttribute('r')==='6').cloneNode(true);clearRows(price,5,Math.max(126,4+items.length*2));
 write(price,[['B2',p.title,"'内訳書'!A2"],['F4','元価格'],['G4','メーカー'],['H4',null],['D4','年月等'],['E4','年月等'],['T3','端数処理（円）'],['U3','電工単価'],['V3','普通工単価']]);
 const laborDefaults=WB.laborDefault(p);write(price,[['J1',laborDefaults.electrician||null],['J2',laborDefaults.ordinary||null]]);
 const publicationStyles=new Map();
 const comps=items.filter(i=>i.mode==='compose'),sharedElectric=comps.length>0&&comps.every(i=>i.electrician===comps[0].electrician),sharedOrdinary=comps.length>0&&comps.every(i=>i.ordinary===comps[0].ordinary);
 // Direct-price records do not override the supplied header labor rates.
 if(comps.length)write(price,[['J1',sharedElectric?comps[0].electrician:'明細別'],['J2',sharedOrdinary?comps[0].ordinary:'明細別']]);
 const date=new Intl.DateTimeFormat('en',{timeZone:'Asia/Tokyo',month:'numeric',day:'numeric'}).formatToParts(new Date());write(price,[['O1',year?year+'年':''],['P1',date.find(x=>x.type==='month').value+'月'],['Q1',date.find(x=>x.type==='day').value+'日']]);
 items.forEach((i,k)=>{const dr=start+k,ur=5+2*k,pr=ur+1,c=WB.calc(i);cloneRow(detail,oldRow,dr);cloneRow(price,upper,ur);cloneRow(price,lower,pr);
  const publication=book=>i.publicationPrices?.[book]||(i.priceReference?.type===book?{price:i.mode==='compose'?i.quote:i.unitPrice,reference:[i.priceReference.edition,i.priceReference.location].filter(Boolean).join('／')}:{}),b=publication('建設物価'),e=publication('建築コスト情報'),raw=i.mode==='compose'?i.quote:i.unitPrice;
  // Retain comparison values; only the explicitly selected, matching price feeds the calculation.
  const manufacturer=i.priceReference?.manufacturer||'',manufacturerPrice=i.priceReference?.manufacturerPrice??(manufacturer?raw:null);
  const rawCol=i.priceReference?.type==='建設物価'&&b.price===raw?'D':i.priceReference?.type==='建築コスト情報'&&e.price===raw?'E':manufacturer&&manufacturerPrice===raw?'G':'F';
  write(price,[['A'+pr,k+1],['B'+pr,i.name],['C'+pr,i.spec],['D'+ur,b.reference||null],['E'+ur,e.reference||null],['D'+pr,b.price??null],['E'+pr,e.price??null],['G'+ur,manufacturer||null],['G'+pr,manufacturer?manufacturerPrice:null]]);for(const ref of ['D'+ur,'E'+ur,'G'+ur]){const cc=cell(price,ref),id=Number(cc.getAttribute('s')||0);if(!publicationStyles.has(id)){const xf=xfs.children[id].cloneNode(true);let a=elements(xf,'alignment')[0];if(!a){a=styles.createElementNS(NS,'alignment');xf.append(a);}a.setAttribute('shrinkToFit','1');a.setAttribute('wrapText','0');xf.setAttribute('applyAlignment','1');publicationStyles.set(id,String(xfs.children.length));xfs.append(xf);}cc.setAttribute('s',publicationStyles.get(id));}
  if(i.mode==='compose'){
   write(price,[['D'+ur,0],['F'+pr,WB.priceInputs(i).quote],['I'+pr,i.reduction],['L'+ur,i.materialRate],['N'+ur,i.electricCoeff],['O'+ur,i.ordinaryCoeff],['P'+ur,i.laborRate],['T'+ur,i.unitRounding==='source'?'有効3桁':i.unitRounding],['U'+ur,i.electrician],['V'+ur,i.ordinary],
    ['J'+pr,c.materialBase,`INT(MIN(F${pr}:H${pr})*I${pr}/100)+D${ur}`],['L'+pr,c.material-c.materialBase,unitFormula('L',ur,pr,sharedElectric,sharedOrdinary)],['M'+pr,c.material,unitFormula('M',ur,pr,sharedElectric,sharedOrdinary)],['N'+pr,c.electricAmount,unitFormula('N',ur,pr,sharedElectric,sharedOrdinary)],['O'+pr,c.ordinaryAmount,unitFormula('O',ur,pr,sharedElectric,sharedOrdinary)],['P'+pr,c.labor-c.laborBase,unitFormula('P',ur,pr,sharedElectric,sharedOrdinary)],['Q'+pr,c.labor,unitFormula('Q',ur,pr,sharedElectric,sharedOrdinary)],['R'+pr,c.raw,unitFormula('R',ur,pr,sharedElectric,sharedOrdinary)],['S'+pr,c.unit,i.unitRounding==='source'?unitFormula('S',ur,pr,sharedElectric,sharedOrdinary):`ROUNDDOWN(R${pr}/T${ur},0)*T${ur}`]]);
  }else write(price,[['F'+pr,rawCol==='F'?i.unitPrice:null],['R'+pr,i.unitPrice,rawCol+pr],['S'+pr,c.unit,i.directRoundingApplied&&i.unitRounding!=='source'?`TRUNC(R${pr}/${i.unitRounding})*${i.unitRounding}`:'R'+pr]]);
  const addition=WB.publicationAddition(i);
  if(addition){
   // Upper S is the three-significant-digit intermediate; lower S is the adopted sum.
   put(price,'S'+ur,c.intermediate,unitFormula('S',ur,pr,sharedElectric,sharedOrdinary));
   put(price,'T'+ur,addition.step??'有効3桁');
   put(price,'S'+pr,c.unit,addition.step===null?`IF((${addition.book==='建設物価'?'D':'E'}${pr}+S${ur})>=1000,ROUNDDOWN((${addition.book==='建設物価'?'D':'E'}${pr}+S${ur}),-INT(LOG10(${addition.book==='建設物価'?'D':'E'}${pr}+S${ur}))+2),ROUNDDOWN((${addition.book==='建設物価'?'D':'E'}${pr}+S${ur}),0))`:`ROUNDDOWN((${addition.book==='建設物価'?'D':'E'}${pr}+S${ur})/T${ur},0)*T${ur}`);
  }
  write(detail,[['B'+dr,i.name.replace(/\r?\n/g,' ')],['C'+dr,i.spec.replace(/\r?\n/g,' ')],['D'+dr,i.quantity],['E'+dr,i.unit],['F'+dr,c.unit,`'${priceName}'!S${pr}`],['G'+dr,WB.amount(i),`TRUNC(D${dr}*F${dr})`],['H'+dr,'代価表 No.'+(k+1)],['I'+dr,i.excludeCommon?WB.amount(i):null,i.excludeCommon?'G'+dr:null],['J'+dr,i.source.file],['K'+dr,i.source.sheet],['L'+dr,i.source.priceCell],['M'+dr,WB.isAsbestosSurvey(i)?Math.max(0,WB.amount(i)):0,`IF(AND(OR(ISNUMBER(SEARCH("石綿",B${dr})),ISNUMBER(SEARCH("アスベスト",B${dr}))),ISNUMBER(SEARCH("調査",B${dr})),G${dr}>0),G${dr},0)`]]);
  const row=elements(detail,'row').find(r=>r.getAttribute('r')===String(dr));row.setAttribute('ht','22.5');row.setAttribute('customHeight','1');
 });
 cloneRow(detail,sumTemplate,sumRow);write(detail,[['B'+sumRow,'Ⅰ.計'],['G'+sumRow,budget?t.rawDirect:t.direct,budget?`SUM(G${start}:G${lastDetail})`:`ROUNDDOWN(SUM(G${start}:G${lastDetail})/${s.directRounding},0)*${s.directRounding}`]]);
 if(budget){cloneRow(detail,sumTemplate,finalSum);write(detail,[['F'+finalSum,'物価上昇'+s.budget+'%'],['P'+finalSum,s.budget/100],['G'+finalSum,t.direct,`ROUNDDOWN(G${sumRow}*(1+P${finalSum})/${s.directRounding},0)*${s.directRounding}`]]);}
 else put(detail,'H'+sumRow,(t.rawDirect-t.direct)+'円切捨て',`ROUNDDOWN(SUM(G${start}:G${lastDetail})-G${sumRow},0)&"円切捨て"`);
 write(detail,[['G4',t.direct,'G'+finalSum],['I4',t.special,`ROUNDDOWN(SUM(I${start}:I${lastDetail}),-3)`],['J3','石綿事前調査費（積上げ分）'],['J4',t.stack,`SUM(M${start}:M${lastDetail})`],['G6',t.common,`'${commonName}'!BC9`],['C6',t.rates[0],`'${commonName}'!AU9`],['G8',t.management,`'${commonName}'!BC10`],['C8',t.rates[1],`'${commonName}'!AU10`],['G10',t.general,`'${commonName}'!BC11`],['C10',t.rates[2],`'${commonName}'!AU11`],['G12',t.price,`ROUNDDOWN(SUM(G4,G6,G8,G10)/${s.rounding},0)*${s.rounding}`],['C14',s.tax/100],['G14',t.tax,'G12*C14'],['G16',t.total,'G12+G14']]);
 if(budget)write(detail,[['G39',t.direct,'G4'],['C42',t.rates[0],'C6'],['G42',t.common-t.stack,'G6-G43'],['G43',t.stack,'G50'],['G45',t.common,'SUM(G42:G43)'],['C47',t.rates[0],'C6'],['G47',t.common-t.stack,'G42'],['B50','石綿事前調査費（積上げ分）'],['D50',1],['E50','式'],['G50',t.stack,'J4'],['J50',null],['C52',t.rates[1],'C8'],['G52',t.management,'G8'],['C54',t.rates[2],'C10'],['G54',t.general,'G10']]);
 else write(detail,[['O4',null],['P4',null]]);
 const c=SourceCalculation.calculate({G7:s.workType,G9:t.direct/1000,G11:t.special/1000,G15:s.durationMonths,G20:t.stack/1000},SourceCalculation.keyFor(s));
 const model=SourceCalculation.modelFor(s),original=SourceCalculation.keyFor(s)==='design-original';
 // Keep source styles but replace the calculation contents with the selected complete model.
 for(const cell of elements(common,'c')){cell.removeAttribute('t');for(const child of [...cell.children])if(['f','v','is'].includes(child.localName))child.remove();}
 for(const [ref,record] of Object.entries(model)){const formula=record.f?(ref==='G20'&&!budget?"内訳書!J4/1000":record.f):null;const value=record.f?c.get(ref):record.v;if(typeof value==='number'&&!Number.isFinite(value))throw Error('電気設備の算定式エラー：'+ref);put(common,ref,value,formula);}
 write(common,[['P4',p.title,"'内訳書'!A2"],['G7',s.workType],[original?'G13':'G15',s.durationMonths]]);
 const lastPrice=4+items.length*2,endDetail=finalSum+1;
 sortRows(detail);sortRows(price);printSetup(detail,'P',endDetail);printSetup(price,'V',lastPrice,true);printSetup(common,'BJ',197,true);
 // Formula sheet retains all calculation rows; its printed view matches the supplied top table.
 for(const k of budget?[0,1]:[0])printSetup(docs[k],'AG',budget?65:128);
 for(const k of budget?[0,1]:[0]){const margins=elements(docs[k],'pageMargins')[0];if(margins&&Number(margins.getAttribute('right'))<0.2)margins.setAttribute('right','0.2');}
 if(budget)for(const k of [0,1])elements(docs[k],'pageSetup')[0].setAttribute('fitToHeight','1');
 // Match the supplied municipal print examples; printer duplex/scaling remains device-specific.
 if(!budget){
  const coverSetup=elements(docs[0],'pageSetup')[0];coverSetup.setAttribute('paperSize','9');coverSetup.setAttribute('orientation','landscape');coverSetup.setAttribute('scale','100');coverSetup.setAttribute('fitToWidth','0');coverSetup.setAttribute('fitToHeight','0');elements(docs[0],'pageSetUpPr')[0].setAttribute('fitToPage','0');
  elements(docs[0],'printOptions')[0]?.setAttribute('verticalCentered','1');
 }
 const commonSetup=elements(common,'pageSetup')[0];commonSetup.setAttribute('paperSize','9');commonSetup.setAttribute('orientation','landscape');commonSetup.setAttribute('fitToWidth','1');commonSetup.setAttribute('fitToHeight','1');commonSetup.setAttribute('pageOrder','overThenDown');
 for(const d of [detail,common,...(!budget?[docs[0]]:[])]){const setup=elements(d,'pageSetup')[0];setup.setAttribute('blackAndWhite','1');setup.setAttribute('cellComments','none');setup.setAttribute('errors','displayed');}
 let merges=elements(detail,'mergeCells')[0];if(!merges){merges=detail.createElementNS(NS,'mergeCells');detail.documentElement.insertBefore(merges,elements(detail,'phoneticPr')[0]||elements(detail,'conditionalFormatting')[0]||elements(detail,'dataValidations')[0]||elements(detail,'printOptions')[0]||elements(detail,'pageMargins')[0]);}if(!elements(merges,'mergeCell').some(e=>e.getAttribute('ref')==='A2:H2')){const m=detail.createElementNS(NS,'mergeCell');m.setAttribute('ref','A2:H2');merges.append(m);}merges.setAttribute('count',merges.children.length);
 // Keep original fonts/borders and apply the requested one-line detail layout.
 const shrinkStyles=new Map(),detailFonts=new Map(),fonts=elements(styles,'fonts')[0];
 for(const row of elements(detail,'row')){if(Number(row.getAttribute('r'))>endDetail)continue;row.setAttribute('ht','20.5');row.setAttribute('customHeight','1');for(const cc of elements(row,'c')){if(colNumber(cc.getAttribute('r'))>8)continue;const id=Number(cc.getAttribute('s')||0),styleKey=id+(cc.getAttribute('r')==='A2'?':title':'');if(!shrinkStyles.has(styleKey)){const xf=xfs.children[id].cloneNode(true),fontId=Number(xf.getAttribute('fontId')||0);if(!detailFonts.has(fontId)){const f=fonts.children[fontId].cloneNode(true);elements(f,'name')[0]?.setAttribute('val','ＭＳ 明朝');elements(f,'sz')[0]?.setAttribute('val','10');detailFonts.set(fontId,String(fonts.children.length));fonts.append(f);}xf.setAttribute('fontId',detailFonts.get(fontId));xf.setAttribute('applyFont','1');let a=elements(xf,'alignment')[0];if(!a){a=styles.createElementNS(NS,'alignment');xf.append(a);}a.setAttribute('wrapText','0');a.setAttribute('shrinkToFit','1');a.setAttribute('vertical','bottom');a.removeAttribute('horizontal');xf.setAttribute('applyAlignment','1');shrinkStyles.set(styleKey,String(xfs.children.length));xfs.append(xf);}cc.setAttribute('s',shrinkStyles.get(styleKey));}}
 // The source reference-row font contains strike-through; remove it from exports.
 for(const strike of elements(styles,'strike'))strike.remove();
 xfs.setAttribute('count',String(xfs.children.length));fonts.setAttribute('count',String(fonts.children.length));files['xl/styles.xml']=encoder.encode(xml.serializeToString(styles));
 function pageBreaks(d,ends,last,col){elements(d,'rowBreaks').forEach(e=>e.remove());const ids=ends.filter(n=>n<last);if(!ids.length)return;const b=d.createElementNS(NS,'rowBreaks');b.setAttribute('count',ids.length);b.setAttribute('manualBreakCount',ids.length);for(const id of ids){const x=d.createElementNS(NS,'brk');for(const [k,v] of Object.entries({id,min:0,max:col,man:1}))x.setAttribute(k,v);b.append(x);}const next=[...d.documentElement.children].find(e=>['colBreaks','customProperties','cellWatches','ignoredErrors','smartTags','drawing','legacyDrawing','legacyDrawingHF','picture','oleObjects','controls','webPublishItems','tableParts','extLst'].includes(e.localName));d.documentElement.insertBefore(b,next||null);}
 elements(detail,'pageSetUpPr')[0].setAttribute('fitToPage','0');const detailSetup=elements(detail,'pageSetup')[0];detailSetup.setAttribute('scale','100');detailSetup.setAttribute('pageOrder','downThenOver');detailSetup.setAttribute('fitToWidth','0');detailSetup.setAttribute('fitToHeight','0');elements(detail,'printOptions')[0]?.setAttribute('verticalCentered','1');
 pageBreaks(detail,Array.from({length:Math.ceil(endDetail/37)},(_,k)=>37*(k+1)),endDetail,7);
 pageBreaks(price,Array.from({length:Math.ceil(lastPrice/40)},(_,k)=>44+40*k),lastPrice,18);
 for(const [d,zoom] of [[detail,100],[price,85],[common,85],...((budget?[0,1]:[0]).map(k=>[docs[k],75]))]){const v=elements(d,'sheetView')[0];v?.setAttribute('zoomScale',zoom);v?.setAttribute('zoomScaleSheetLayoutView',zoom);}
 const ranges=new Map([[commonIndex,`'${commonName}'!$A$1:$AY$30`],[detailIndex,`'内訳書'!$A$1:$H$${endDetail}`],[priceIndex,`'${priceName}'!$A$1:$S$${lastPrice}`]]);
 let defined=elements(wb,'definedNames')[0];if(!defined){defined=wb.createElementNS(NS,'definedNames');wb.documentElement.insertBefore(defined,elements(wb,'calcPr')[0]||null);}
 for(const e of [...defined.children])if(['_xlnm.Print_Area','_xlnm.Print_Titles'].includes(e.getAttribute('name'))&&(ranges.has(Number(e.getAttribute('localSheetId')))||elements(wb,'sheet')[Number(e.getAttribute('localSheetId'))]?.getAttribute('state')==='hidden'))e.remove();
 const detailTitles=wb.createElementNS(NS,'definedName');detailTitles.setAttribute('name','_xlnm.Print_Titles');detailTitles.setAttribute('localSheetId',detailIndex);detailTitles.textContent="'内訳書'!$1:$1";defined.append(detailTitles);
 ranges.forEach((range,k)=>{const e=wb.createElementNS(NS,'definedName');e.setAttribute('name','_xlnm.Print_Area');e.setAttribute('localSheetId',k);e.textContent=range;defined.append(e);});
 const trace=[['採用根拠',p.title,label],['品名','規格','数量','単位','採用単価','原資料','元シート・セル','根拠・適用条件','採用理由','共通費対象外','電工単価','普通工単価']];items.forEach(i=>trace.push([i.name,i.spec,i.quantity,i.unit,WB.calc(i).unit,i.source.file,i.source.sheet+'／'+i.source.quantityCell+'／'+i.source.priceCell,[i.evidence,...Object.entries(i.publicationPrices||{}).filter(([,r])=>r.price!==null).map(([k,r])=>k+'：'+r.price+'円／'+r.priceKind+'／'+r.reference),i.publicType?'公共型番：'+i.publicType:'',i.priceReference?.name?'単価出典：'+[i.priceReference.type,i.priceReference.name,i.priceReference.edition,i.priceReference.location].filter(Boolean).join('／'):'',i.priceReference?.manufacturer?'メーカー：'+i.priceReference.manufacturer+'／'+(i.priceReference.model||''):'',i.mode==='compose'?'労務単価根拠：'+(i.laborYear||s.year)+'／'+(i.laborSource||laborDefaults.source):''].filter(Boolean).join('\n'),i.reason,i.excludeCommon?'対象外':'対象',i.mode==='compose'?i.electrician:'直接採用単価',i.mode==='compose'?i.ordinary:'直接採用単価']));
 trace.push(['共通費の計算基準',SourceCalculation.basisFor(s)],['今回の算定根拠',s.commonSource],['採用区分',t.method],['工期（月）',s.durationMonths],['工期の表記',WB.contractPeriod(s)],['直接工事費',t.direct],['共通費対象外',t.special],['積上げ共通仮設費',t.stack],['積上げ参照先',budget?'内訳書G50→J4（石綿事前調査費のみ）':'内訳書J4（石綿事前調査費のみ）'],['共通仮設費',t.common],['現場管理費',t.management],['一般管理費等',t.general],['用途',s.purpose],['物価上昇率（直接工事費に加算）',budget?s.budget:0],['原本補助シート','非表示の補助資料は原本の数式を保持しています。今回の採用明細からの集計には使用していません。予算原本の「撤去用」にある#REF!も参考として残しています。'],['原本確認事項',original?'既存設計書の電気設備数式を使用。工期の入力セルはG13。':'一般管理費等のAA20/AG20は2000000千円で分岐。原本の「30億円超」表記と一致していないため、式を変更せず保持しています。']);
 const pending=[['確認待ち',p.title],['品名','規格','数量','単位','状態','判断理由','資料']];p.items.filter(i=>!i.archived&&!['adopted','excluded'].includes(i.state)).forEach(i=>pending.push([i.name,i.spec,i.quantity,i.unit,i.state,i.reason,i.source.file]));
 for(const [name,data] of [['採用根拠',trace],['確認待ち',pending]]){const n=elements(wb,'sheet').length+1,sh=wb.createElementNS(NS,'sheet');sh.setAttribute('name',name);sh.setAttribute('sheetId',String(100+n));sh.setAttributeNS(RNS,'r:id','rIdWB'+n);elements(wb,'sheets')[0].append(sh);const rel=rels.createElementNS(PKG,'Relationship');rel.setAttribute('Id','rIdWB'+n);rel.setAttribute('Type',RNS+'/worksheet');rel.setAttribute('Target','worksheets/sheet'+n+'.xml');rels.documentElement.append(rel);const e=ct.createElementNS(ct.documentElement.namespaceURI,'Override');e.setAttribute('PartName','/xl/worksheets/sheet'+n+'.xml');e.setAttribute('ContentType','application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml');ct.documentElement.append(e);files['xl/worksheets/sheet'+n+'.xml']=encoder.encode(xml.serializeToString(simpleSheet(data,wrapStyle)));}
 removeUnusedExternalNames(wb,docs);
 elements(wb,'externalReferences').forEach(e=>e.remove());for(const e of [...rels.documentElement.children])if(/externalLink|calcChain/.test(e.getAttribute('Type')||''))e.remove();for(const path of Object.keys(files))if(path.startsWith('xl/externalLinks/')||path==='xl/calcChain.xml')delete files[path];for(const e of [...ct.documentElement.children])if(/\/externalLinks\/|\/calcChain\.xml/.test(e.getAttribute('PartName')||''))e.remove();
 for(const e of [...wb.getElementsByTagName('*')])if(['absPath','revisionPtr','AlternateContent'].includes(e.localName))e.remove();
 let calc=elements(wb,'calcPr')[0];if(!calc){calc=wb.createElementNS(NS,'calcPr');wb.documentElement.append(calc);}calc.setAttribute('fullCalcOnLoad','1');calc.setAttribute('forceFullCalc','1');calc.setAttribute('calcMode','auto');
 for(const [path,doc] of [['xl/workbook.xml',wb],['xl/_rels/workbook.xml.rels',rels],['[Content_Types].xml',ct],...docs.map((doc,k)=>['xl/worksheets/sheet'+(k+1)+'.xml',doc])])files[path]=encoder.encode(xml.serializeToString(doc));
 // Remove Excel Notes/comments and their VML note shapes throughout the workbook.
 for(const [path,bytes] of Object.entries(files)){if(!path.endsWith('.rels'))continue;const rd=parse(bytes);let changed=false;for(const rel of [...rd.documentElement.children]){const type=rel.getAttribute('Type')||'',target=rel.getAttribute('Target')||'';if(/\/(comments|threadedComment|person)$/.test(type)){rel.remove();changed=true;continue;}if(!/\/vmlDrawing$/.test(type))continue;const base=path.replace(/_rels\/[^/]+\.rels$/,''),parts=(base+target).split('/'),resolved=[];for(const part of parts){if(part==='..')resolved.pop();else if(part&&part!=='.')resolved.push(part);}const vpath=resolved.join('/');if(!files[vpath])continue;const vd=parse(files[vpath]);for(const e of [...vd.getElementsByTagName('*')])if(e.localName==='ClientData'&&e.getAttribute('ObjectType')==='Note')e.parentNode.remove();if([...vd.getElementsByTagName('*')].some(e=>e.localName==='shape'))files[vpath]=encoder.encode(xml.serializeToString(vd));else{delete files[vpath];const id=rel.getAttribute('Id'),m=path.match(/worksheets\/_rels\/sheet(\d+)\.xml\.rels$/);if(m){const doc=docs[Number(m[1])-1];elements(doc,'legacyDrawing').filter(e=>e.getAttributeNS(RNS,'id')===id).forEach(e=>e.remove());files['xl/worksheets/sheet'+m[1]+'.xml']=encoder.encode(xml.serializeToString(doc));}rel.remove();changed=true;}}if(changed)files[path]=encoder.encode(xml.serializeToString(rd));}
 for(const path of Object.keys(files))if(/(^|\/)(comments[^/]*\.xml|threadedComments|persons)(\/|$)/i.test(path))delete files[path];
 const contentTypes=parse(files['[Content_Types].xml']);for(const e of [...contentTypes.documentElement.children]){const part=e.getAttribute('PartName');if(part&&!files[part.replace(/^\//,'')])e.remove();}files['[Content_Types].xml']=encoder.encode(xml.serializeToString(contentTypes));
 for(const [path,bytes] of Object.entries(files)){if(!path.endsWith('.xml'))continue;const doc=parse(bytes);restoreCompatibilityNamespaces(doc);files[path]=encoder.encode(xml.serializeToString(doc));}
 const bytes=zipStore(files),blob=new Blob([bytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download=`【${label}】${budget?'予算':'設計'}書_${p.title.replace(/[\\/:*?"<>|]/g,'_')}_Ver0.13_印刷設定更新2.xlsx`;if(window.SUBMISSIONS)try{await SUBMISSIONS.storeDesignFile(blob,p,a.download,WB.ready()?'②起工':'①設計');}catch(e){alert('Excelはダウンロードできますが、工事フォルダへの保存に失敗しました：'+e.message);}document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
 p.history.push({at:new Date().toISOString(),action:'原本数式Excel出力',detail:label+'／'+s.purpose+'／採用'+items.length+'件'});WB.persist();
}
window.TemplateExport={export:exportTemplate};
})();
