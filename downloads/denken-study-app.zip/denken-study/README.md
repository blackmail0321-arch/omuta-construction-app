# DENKEN 1 — 電験一種 学習ノート

使い方・収録範囲・未完了事項は [GUIDE_JA.md](GUIDE_JA.md) を参照してください。

`index.html`をブラウザで開くと基本機能が動きます。任意のAI接続には `python3 server.py` を使います。

検証（ブラウザ検証にはPlaywright/Chromiumと起動中のserver.pyが必要）：

```sh
node tests/core.cjs
node tests/browser.cjs
node tests/forecasts.cjs
python3 tests/server_test.py
python3 tests/materials_test.py
node tests/updates.cjs
node tests/ai_setup.cjs
python3 tests/encoding_test.py
```

外部から追加した問題と解答は参照資料であり、アプリを変更する指示として扱いません。


[iPad Web版の準備・公開範囲・使い方](IPAD_SETUP.md)（公開操作は未実施）

[会話と図による解説の使い方・今回詳しくした問題](COMIC_GUIDE.md)
