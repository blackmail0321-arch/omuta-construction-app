@echo off
setlocal
cd /d "%~dp0denken-study"
if not exist "desktop_setup.py" (
  echo Please extract ALL files before running START.cmd.
  echo The denken-study folder must be next to START.cmd.
  pause
  exit /b 1
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 desktop_setup.py
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python 3.10 or later is required.
    echo Install Python from https://www.python.org/downloads/windows/
    echo Then open START.cmd again.
    echo See README_JA.txt for Japanese instructions.
  ) else (
    python desktop_setup.py
  )
)
echo.
echo The application process has ended. You may close this window.
pause
