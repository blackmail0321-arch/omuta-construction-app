@echo off
setlocal
cd /d "%~dp0denken-study"
if not exist "desktop_setup.py" (
  echo Please extract ALL files before running START.cmd.
  echo The denken-study folder must be next to START.cmd.
  pause
  exit /b 1
)
set "STUDY_PY="
for %%V in (314 313 312 311 310 315 316) do call :find_python "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
for %%V in (314 313 312 311 310 315 316) do call :find_python "%ProgramFiles%\Python%%V\python.exe"
if defined STUDY_PY goto run_installed
where py >nul 2>nul
if errorlevel 1 goto check_python
py -3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>nul
if not errorlevel 1 goto run_launcher
:check_python
where python >nul 2>nul
if errorlevel 1 goto not_found
python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>nul
if not errorlevel 1 goto run_python
goto not_found
:run_installed
"%STUDY_PY%" desktop_setup.py
goto finished
:run_launcher
py -3 desktop_setup.py
goto finished
:run_python
python desktop_setup.py
goto finished
:not_found
echo Python was not found in the standard installation folders.
echo If you already installed Python, do not reinstall it yet.
echo Keep this window open and ask for help locating python.exe.
echo See README_JA.txt for Japanese instructions.
goto finished
:find_python
if defined STUDY_PY exit /b 0
if exist "%~1" set "STUDY_PY=%~1"
exit /b 0
:finished
echo.
echo The application process has ended. You may close this window.
pause
