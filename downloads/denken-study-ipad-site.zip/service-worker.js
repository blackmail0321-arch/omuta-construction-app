'use strict';
const PREFIX='denken-ipad:'+self.registration.scope+':';
const CACHE=PREFIX+'66297fb505a90ec4';
const CORE=['index.html','manifest.webmanifest','icon-180.png','icon-192.png','icon-512.png'].map(n=>new URL(n,self.registration.scope).href);
self.addEventListener('install',event=>event.waitUntil((async()=>{try{const cache=await caches.open(CACHE);await cache.addAll(CORE);await self.skipWaiting()}catch(e){await caches.delete(CACHE);throw e}})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const name of await caches.keys())if(name.startsWith(PREFIX)&&name!==CACHE)await caches.delete(name);await self.clients.claim()})()));
self.addEventListener('fetch',event=>{const req=event.request,url=new URL(req.url),scope=new URL(self.registration.scope);if(req.method!=='GET'||url.origin!==scope.origin||!url.pathname.startsWith(scope.pathname))return;if(req.mode==='navigate'){event.respondWith((async()=>{const cache=await caches.open(CACHE);return await cache.match(CORE[0])||fetch(req)})());return}if(!CORE.includes(url.href))return;event.respondWith((async()=>{const cache=await caches.open(CACHE);return await cache.match(req)||fetch(req)})())});
